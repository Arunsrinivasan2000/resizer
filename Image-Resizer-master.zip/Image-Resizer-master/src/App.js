import ImageUpload from './ImageUpload';
function App() {
  return (
    <div className="App">
      <ImageUpload/>
    </div>
  );
}

export default App;
